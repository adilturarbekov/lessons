a = 5
b = 4
c = 6


a = 7%3
b = 4.8
print (a*b)


a = 20*2
b = 160/40
print (a=b)

a = 9*2
b = 20-2
print (a=b)
