a = 10//5
b = 10/5

if a == b:
	print ('oni ravni')
elif a != b:
	print ('oni ne ravni')

