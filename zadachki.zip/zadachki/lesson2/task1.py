
a = 3
b = 3
if a>b:
	print ('не верно')
elif a<b:
	print ('a<b')
elif a == b:
	print ('верно')
else:
	print ('ne verno')
