a = int(input('Введите первое число:'))
b = int(input('Введите второе число:'))
c = int(input('Введите третье число:'))
if a<b and a<c:
	print ( a , 'самое маленькое число' )
elif b<a and b<c: 
	print ( b , 'самое маленькое число' )
elif c<a and c<b:
	print ( c , 'самое маленькое число' )
