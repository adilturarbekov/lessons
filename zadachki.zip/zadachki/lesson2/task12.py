a=int(input('введите любой год:'))
b=2022
if a>b:
	print (a , 'Год еще не наступил')
elif a<b:
	print (a , 'Год уже прошел')
else:
	print (a , 'Текущий год')

