a = int(input('введите год рождения:'))
b = 2022
if b-a>=18:
	print ('совершеннолетний')
elif b-a<=4:
	print ('ребенок')
elif b-a<18:
	print ('несовершеннолетний')
else:
	print ('ребенок')

