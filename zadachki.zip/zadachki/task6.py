a = 22
b = 78
print ((a/b)*100)

