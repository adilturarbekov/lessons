a = 10
b = 13
c = 14.7
d = 13
e = 8

print (a-e**(b/d)%c)



print (10-8**(13/13)%14.7)

