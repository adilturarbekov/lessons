a = 1997
b = 2022
c = (2022-1997)+2
d = (2022-1997)-2
print ((b-a)+2);
print ((b-a)-2)

print (c)

print (d)

print ((2022-1997)+2)

print ((2022-1997)-2)



