a = 17925
b = (34**2)
c = 26*3
d = 17*33
e = 4394*4
print (a>=b)
print (a>=c)
print (a>=d)
print (a>=e)

