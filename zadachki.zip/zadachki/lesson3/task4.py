a = input('What is your name?:')
b = int(input('How old are you?:'))
c = input('Your favorite movie?:')
print ('Hello! ' , a)
print ('Very intresting movie!' , c)

