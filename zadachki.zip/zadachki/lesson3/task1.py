a = True
b=str(a)
print (type(b))
print (type(a))
