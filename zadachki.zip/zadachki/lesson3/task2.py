a = input('Введите символ:')

b = 'GitHub'
print (a.join(b))
