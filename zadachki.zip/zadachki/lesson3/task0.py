a = 'Hello!'
b = 'My name is Loco'
print(a.upper())
print(b.lower())


