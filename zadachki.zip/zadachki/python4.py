a = 17*3
b = 12*5
print (a>b)

a = 12**3
b = 13*7
print (a>b)

a = 4**5
b = 512+512
print (a>b)

