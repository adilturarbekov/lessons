a = -24
b = 10
print (a//b)

