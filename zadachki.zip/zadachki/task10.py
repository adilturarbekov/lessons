a = 25
b = 75
c = 10
d = 95
print ((a+b+c+d)/4)
